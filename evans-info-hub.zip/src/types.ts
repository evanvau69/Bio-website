/**
 * types.ts
 * Type definitions for Evan's Bio Profile & Retro Games
 */

export type Language = 'en' | 'bn';

export interface Reaction {
  id: string;
  emoji: string;
  x: number;
  y: number;
  rotation: number;
}

export interface Enemy {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  emoji: string;
  color: string;
  isHit: boolean;
  type: 'crawler' | 'ghost' | 'boss' | 'glitch';
  speed: number;
}

export interface Particle {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  life: number;
  maxLife: number;
}

export interface HighScore {
  name: string;
  score: number;
  date: string;
}
