import React, { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import SplashView from './components/SplashView';
import BioView from './components/BioView';

export default function App() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div id="app-root-container" className="w-full min-h-screen bg-[#0A0A0B]">
      <AnimatePresence mode="wait">
        {!isOpen ? (
          <motion.div
            key="splash-wrapper"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.4 }}
            className="w-full h-full"
          >
            <SplashView onOpen={() => setIsOpen(true)} />
          </motion.div>
        ) : (
          <motion.div
            key="bio-wrapper"
            initial={{ opacity: 0, scale: 1.05 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
            className="w-full h-full"
          >
            <BioView />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

