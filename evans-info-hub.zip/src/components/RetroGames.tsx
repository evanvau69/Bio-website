import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, RotateCcw, ShieldAlert, Award, Star, Zap, Volume2, Target, Crosshair } from 'lucide-react';
import { soundEngine } from './SoundEngine';
import { Enemy, Particle } from '../types';

export default function RetroGames() {
  const [activeTab, setActiveTab] = useState<'smasher' | 'reflex'>('smasher');
  
  // Game 1: Enemy Smasher State
  const [smasherPlaying, setSmasherPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [highScore, setHighScore] = useState(() => {
    return parseInt(localStorage.getItem('evan_smasher_high') || '0', 10);
  });
  const [consecutiveKills, setConsecutiveKills] = useState(0);
  
  // Game 2: Hacker timing reflex tap State
  const [reflexPlaying, setReflexPlaying] = useState(false);
  const [reflexScore, setReflexScore] = useState(0);
  const [targetDegree, setTargetDegree] = useState(180); // Goal angle
  const [currentDegree, setCurrentDegree] = useState(0); // Spinner angle
  const [spinSpeed, setSpinSpeed] = useState(3);
  const [reflexLives, setReflexLives] = useState(3);
  const [reflexHigh, setReflexHigh] = useState(() => {
    return parseInt(localStorage.getItem('evan_reflex_high') || '0', 10);
  });

  const smasherCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const enemiesRef = useRef<Enemy[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const animationFrameId = useRef<number | null>(null);
  const gameStatsRef = useRef({ score: 0, lives: 3 });

  // Sync refs with state to avoid closure issues in canvas loop
  useEffect(() => {
    gameStatsRef.current = { score, lives };
  }, [score, lives]);

  // Game 1 Canvas Game Loop
  useEffect(() => {
    if (!smasherPlaying) {
      if (animationFrameId.current) {
        cancelAnimationFrame(animationFrameId.current);
      }
      return;
    }

    const canvas = smasherCanvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Resize canvas
    const resizeCanvas = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width;
      canvas.height = 360;
    };
    resizeCanvas();

    // Initialize lists
    enemiesRef.current = [];
    particlesRef.current = [];

    // Spawn mechanism
    let lastSpawn = 0;
    const enemyEmojis = ['💀', '👹', '👾', '🕷️', '💻', '☣️'];
    const colors = ['#f43f5e', '#a855f7', '#06b6d4', '#eab308', '#22c55e'];

    const spawnEnemy = () => {
      const size = Math.random() * 20 + 22;
      const x = Math.random() * (canvas.width - size * 2) + size;
      const type = Math.random() > 0.8 ? 'boss' : 'crawler';
      const speedMultiplier = 1.2 + (gameStatsRef.current.score * 0.05);

      const enemy: Enemy = {
        id: Math.random().toString(),
        x,
        y: -size,
        vx: (Math.random() * 2 - 1) * 0.8,
        vy: (Math.random() * 1.5 + 1.2) * speedMultiplier,
        size,
        emoji: type === 'boss' ? '👹' : enemyEmojis[Math.floor(Math.random() * enemyEmojis.length)],
        color: colors[Math.floor(Math.random() * colors.length)],
        isHit: false,
        type,
        speed: speedMultiplier
      };
      enemiesRef.current.push(enemy);
    };

    // Main Update and Draw Cycle
    const update = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Draw subtle futuristic matrix background grid in canvas
      ctx.strokeStyle = 'rgba(139, 92, 246, 0.05)';
      ctx.lineWidth = 1;
      const gridSize = 30;
      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      const now = Date.now();
      if (now - lastSpawn > Math.max(1200 - gameStatsRef.current.score * 20, 600)) {
        spawnEnemy();
        lastSpawn = now;
      }

      // Update and draw particles
      particlesRef.current = particlesRef.current.filter((p) => {
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.05; // gravity
        p.life--;

        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 3 * (p.life / p.maxLife), 0, Math.PI * 2);
        ctx.fill();

        return p.life > 0;
      });

      // Update and draw enemies
      enemiesRef.current = enemiesRef.current.filter((e) => {
        e.x += e.vx;
        e.y += e.vy;

        // Bounce horizontal edges
        if (e.x - e.size < 0 || e.x + e.size > canvas.width) {
          e.vx *= -1;
        }

        // Draw laser pointer target glow if mouse is close
        ctx.shadowBlur = 10;
        ctx.shadowColor = e.color;

        // Render Enemy
        ctx.font = `${e.size}px Arial`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(e.emoji, e.x, e.y);
        ctx.shadowBlur = 0; // reset

        // Miss check
        if (e.y > canvas.height + e.size) {
          // Play loss chime or decrement live
          setLives((l) => {
            const nextL = l - 1;
            if (nextL <= 0) {
              soundEngine.playGameOver();
              setSmasherPlaying(false);
            } else {
              soundEngine.playLaser(); // alarm style sound
            }
            return nextL;
          });
          return false; // remove
        }

        return true;
      });

      animationFrameId.current = requestAnimationFrame(update);
    };

    update();

    return () => {
      if (animationFrameId.current) {
        cancelAnimationFrame(animationFrameId.current);
      }
    };
  }, [smasherPlaying]);

  // Click Handler for Canvas Game 1
  const handleSmasherClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!smasherPlaying) return;
    const canvas = smasherCanvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    let hit = false;

    enemiesRef.current = enemiesRef.current.filter((enemy) => {
      // Calculate distance between click and enemy center
      const dist = Math.hypot(enemy.x - clickX, enemy.y - clickY);
      if (dist < enemy.size * 1.5) {
        hit = true;
        // Synthesize explosion sound
        soundEngine.playSmash();

        // Increment Score
        setScore((prev) => {
          const added = enemy.type === 'boss' ? 30 : 10;
          const nextS = prev + added;
          if (nextS > highScore) {
            setHighScore(nextS);
            localStorage.setItem('evan_smasher_high', nextS.toString());
          }
          return nextS;
        });

        // Trigger particle burst
        for (let i = 0; i < 12; i++) {
          particlesRef.current.push({
            id: Math.random().toString(),
            x: enemy.x,
            y: enemy.y,
            vx: (Math.random() * 4 - 2) * 2.5,
            vy: (Math.random() * 4 - 2) * 2.5,
            color: enemy.color,
            life: 30,
            maxLife: 30
          });
        }
        return false; // remove enemy
      }
      return true; // keep
    });

    if (hit) {
      setConsecutiveKills((k) => k + 1);
    } else {
      // Misclick: play laser miss sound
      soundEngine.playLaser();
      setConsecutiveKills(0);
    }
  };

  // Game 2: Reflex Hacker timing loop
  useEffect(() => {
    if (!reflexPlaying) return;

    const interval = setInterval(() => {
      setCurrentDegree((deg) => {
        return (deg + spinSpeed) % 360;
      });
    }, 16);

    return () => clearInterval(interval);
  }, [reflexPlaying, spinSpeed]);

  // Game 2 target placement action
  const handleHackerTap = () => {
    if (!reflexPlaying) return;

    const diff = Math.abs(currentDegree - targetDegree);
    // Allow standard 16 degrees of tolerance for success
    if (diff <= 18 || diff >= 342) {
      soundEngine.playPop();
      setReflexScore((s) => {
        const nextS = s + 10;
        if (nextS > reflexHigh) {
          setReflexHigh(nextS);
          localStorage.setItem('evan_reflex_high', nextS.toString());
        }
        return nextS;
      });

      // Spawn next target randomly
      setTargetDegree(Math.floor(Math.random() * 280) + 40);
      setSpinSpeed((speed) => Math.min(speed + 0.4, 9)); // accelerate speed
    } else {
      soundEngine.playLaser(); // fail buzz
      setReflexLives((l) => {
        const nextL = l - 1;
        if (nextL <= 0) {
          soundEngine.playGameOver();
          setReflexPlaying(false);
        }
        return nextL;
      });
    }
  };

  const startSmasherGame = () => {
    soundEngine.playWinChime();
    setScore(0);
    setLives(3);
    setConsecutiveKills(0);
    setSmasherPlaying(true);
  };

  const startReflexGame = () => {
    soundEngine.playWinChime();
    setReflexScore(0);
    setReflexLives(3);
    setSpinSpeed(3);
    setReflexPlaying(true);
  };

  return (
    <div className="bg-purple-950/20 border border-purple-500/30 rounded-3xl p-4 md:p-6 shadow-2xl backdrop-blur-md">
      {/* Tab Selectors */}
      <div className="flex bg-black/40 p-1.5 rounded-2xl mb-5 border border-purple-500/10">
        <button
          onClick={() => {
            soundEngine.playPop();
            setActiveTab('smasher');
          }}
          className={`flex-1 py-3 text-center rounded-xl font-mono text-sm font-bold tracking-wide transition-all ${
            activeTab === 'smasher'
              ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg'
              : 'text-purple-300 hover:text-white'
          }`}
        >
          🎮 ENEMY SMASHER (শত্রু নিধন)
        </button>
        <button
          onClick={() => {
            soundEngine.playPop();
            setActiveTab('reflex');
          }}
          className={`flex-1 py-3 text-center rounded-xl font-mono text-sm font-bold tracking-wide transition-all ${
            activeTab === 'reflex'
              ? 'bg-gradient-to-r from-purple-600 to-cyan-500 text-white shadow-lg'
              : 'text-purple-300 hover:text-white'
          }`}
        >
          ⚡ CYBER HACKER (রিফ্লেক্স হ্যাকিং)
        </button>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'smasher' ? (
          <motion.div
            key="smasher"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex flex-col"
          >
            {/* Smasher UI Panel */}
            <div className="flex justify-between items-center bg-black/30 p-3 rounded-2xl mb-3 border border-purple-500/10 font-mono text-xs text-purple-200">
              <div className="flex items-center space-x-2">
                <Target size={14} className="text-pink-500" />
                <span>Score: <b className="text-pink-400 text-sm">{score}</b></span>
              </div>
              <div className="flex items-center space-x-1">
                <span>Lives:</span>
                <span className="text-red-500 tracking-tight text-sm">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <span key={i}>{i < lives ? '❤️' : '🖤'}</span>
                  ))}
                </span>
              </div>
              <div className="flex items-center space-x-1.5 text-yellow-400">
                <Award size={14} />
                <span>Record: <b>{highScore}</b></span>
              </div>
            </div>

            {/* Canvas Container */}
            <div className="relative bg-[#0d0a16] border-2 border-dashed border-purple-500/20 rounded-2xl h-80 overflow-hidden flex items-center justify-center">
              {smasherPlaying ? (
                <canvas
                  id="canvas-enemy-smasher"
                  ref={smasherCanvasRef}
                  onClick={handleSmasherClick}
                  className="w-full h-full cursor-crosshair block"
                />
              ) : (
                <div className="flex flex-col items-center justify-center p-6 text-center z-10 select-none">
                  <div className="text-5xl mb-3 animate-float-slow">💀</div>
                  <h3 className="text-xl font-bold text-white mb-2 font-mono">
                    ENEMY SMASHER ARCADE
                  </h3>
                  <p className="text-gray-400 text-xs max-w-xs mb-5 font-mono leading-relaxed">
                    Tap/Click floating enemies (💀, 👹, 👾) to smash them! Don't let them hit the bottom of the screen.
                  </p>
                  <button
                    id="btn-play-smasher"
                    onClick={startSmasherGame}
                    className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-pink-500 to-purple-600 rounded-xl font-bold tracking-wider font-mono hover:scale-105 active:scale-95 transition-transform"
                  >
                    <Play size={16} fill="white" />
                    <span>START GAME</span>
                  </button>
                </div>
              )}

              {/* Aim helper HUD */}
              {smasherPlaying && (
                <div className="absolute top-2 left-2 pointer-events-none opacity-30 text-[10px] font-mono text-cyan-400">
                  <Crosshair className="inline-block mr-1 w-3 h-3 animate-spin-slow" /> Target Locked
                </div>
              )}
            </div>

            <div className="mt-3 flex items-center justify-between text-[11px] font-mono text-purple-400/80">
              <span>🎯 Destroy glitch enemies instantly to score multipliers</span>
              <span>Sound Feedback: Synthesized Boom 💥</span>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="reflex"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex flex-col"
          >
            {/* Timing Reflex Game UI */}
            <div className="flex justify-between items-center bg-black/30 p-3 rounded-2xl mb-3 border border-purple-500/10 font-mono text-xs text-purple-200">
              <div className="flex items-center space-x-1.5">
                <Zap size={14} className="text-cyan-400" />
                <span>Bypasses: <b className="text-cyan-300 text-sm">{reflexScore}</b></span>
              </div>
              <div className="flex items-center space-x-1">
                <span>Shields:</span>
                <span className="text-red-500 text-sm">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <span key={i}>{i < reflexLives ? '⚡' : '💀'}</span>
                  ))}
                </span>
              </div>
              <div className="flex items-center space-x-1.5 text-yellow-400">
                <Award size={14} />
                <span>Best: <b>{reflexHigh}</b></span>
              </div>
            </div>

            {/* Timing Dial Container */}
            <div className="relative bg-[#0d0a16] border border-purple-500/20 rounded-2xl h-80 overflow-hidden flex flex-col items-center justify-center select-none">
              {reflexPlaying ? (
                <div className="flex flex-col items-center">
                  <div className="relative w-44 h-44 mb-6">
                    {/* Ring Track */}
                    <div className="absolute inset-0 rounded-full border-4 border-purple-900/40" />

                    {/* Success target sweep slot arc */}
                    <div 
                      className="absolute w-8 h-8 rounded-full bg-cyan-400/20 border-2 border-cyan-400 flex items-center justify-center text-[10px] shadow-[0_0_10px_#22d3ee]"
                      style={{
                        top: 'calc(50% - 16px)',
                        left: 'calc(50% - 16px)',
                        transform: `rotate(${targetDegree}deg) translate(80px) rotate(-${targetDegree}deg)`
                      }}
                    >
                      🎯
                    </div>

                    {/* Spinning Indicator */}
                    <div 
                      className="absolute w-5 h-5 rounded-full bg-purple-500 border border-white shadow-[0_0_12px_#a855f7]"
                      style={{
                        top: 'calc(50% - 10px)',
                        left: 'calc(50% - 10px)',
                        transform: `rotate(${currentDegree}deg) translate(80px)`
                      }}
                    />

                    {/* Inner Center Hacker Module */}
                    <div className="absolute inset-8 rounded-full bg-[#151126] border border-purple-500/20 flex flex-col items-center justify-center">
                      <span className="text-[10px] font-mono text-purple-400">SPEED</span>
                      <span className="text-base font-bold font-mono text-white">
                        {spinSpeed.toFixed(1)}x
                      </span>
                    </div>
                  </div>

                  <button
                    id="btn-trigger-hack"
                    onClick={handleHackerTap}
                    className="px-12 py-3 bg-gradient-to-r from-cyan-500 to-purple-600 text-white rounded-xl font-bold tracking-widest font-mono text-xs hover:scale-105 active:scale-95 transition-transform shadow-lg shadow-cyan-500/20"
                  >
                    HACK INTERCEPT!
                  </button>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center p-6 text-center">
                  <div className="text-5xl mb-3 animate-spin-slow">⚙️</div>
                  <h3 className="text-xl font-bold text-white mb-2 font-mono">
                    CYBER REFLEX HACK
                  </h3>
                  <p className="text-gray-400 text-xs max-w-xs mb-5 font-mono leading-relaxed">
                    Click "HACK INTERCEPT" exactly when the purple spinner overlaps the blue target slot!
                  </p>
                  <button
                    id="btn-play-reflex"
                    onClick={startReflexGame}
                    className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-xl font-bold tracking-wider font-mono hover:scale-105 active:scale-95 transition-transform"
                  >
                    <Play size={16} fill="white" />
                    <span>LOAD SYSTEM</span>
                  </button>
                </div>
              )}
            </div>

            <div className="mt-3 flex items-center justify-between text-[11px] font-mono text-purple-400/80">
              <span>🎯 Tap precisely. The speed scales as you score perfect captures</span>
              <span>Sound Feedback: Synth chime 🎵</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
