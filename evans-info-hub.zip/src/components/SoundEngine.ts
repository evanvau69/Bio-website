/**
 * SoundEngine.ts
 * Synthesizes retro-arcade sound effects and looping background tracks using Web Audio API.
 * Ensures instant, lag-free sound effects with 100% offline reliability.
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private bgmNode: OscillatorNode | null = null;
  private bgmGain: GainNode | null = null;
  private bgmInterval: any = null;
  private isBgmPlaying: boolean = false;
  private bpm: number = 120;
  private currentStep: number = 0;
  private volume: number = 0.4;

  constructor() {
    // AudioContext will be initialized on user interaction to comply with browser autoplay policies
  }

  private initCtx() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.bgmGain) {
      this.bgmGain.gain.setValueAtTime(this.volume * 0.15, this.ctx?.currentTime || 0);
    }
  }

  // Laser effect for tapping or shooting
  playLaser() {
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(800, t);
    osc.frequency.exponentialRampToValueAtTime(100, t + 0.15);

    gain.gain.setValueAtTime(this.volume * 0.25, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.15);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.15);
  }

  // Explosion effect for smashing enemies
  playSmash() {
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(250, t);
    osc.frequency.exponentialRampToValueAtTime(40, t + 0.25);

    // Add noise for a punchy boom
    const bufferSize = this.ctx.sampleRate * 0.2;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const noiseFilter = this.ctx.createBiquadFilter();
    noiseFilter.type = 'lowpass';
    noiseFilter.frequency.setValueAtTime(400, t);
    noiseFilter.frequency.exponentialRampToValueAtTime(80, t + 0.25);

    const noiseGain = this.ctx.createGain();
    noiseGain.gain.setValueAtTime(this.volume * 0.4, t);
    noiseGain.gain.exponentialRampToValueAtTime(0.01, t + 0.2);

    noise.connect(noiseFilter);
    noiseFilter.connect(noiseGain);
    noiseGain.connect(this.ctx.destination);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    gain.gain.setValueAtTime(this.volume * 0.3, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.25);

    osc.start(t);
    osc.stop(t + 0.25);
    noise.start(t);
    noise.stop(t + 0.25);
  }

  // Floating bubble pop for clicking emojis
  playPop() {
    this.initCtx();
    if (!this.ctx) return;

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(300, t);
    osc.frequency.exponentialRampToValueAtTime(1200, t + 0.1);

    gain.gain.setValueAtTime(this.volume * 0.2, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.1);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.1);
  }

  // Winning chime when high score is broken
  playWinChime() {
    this.initCtx();
    if (!this.ctx) return;

    const notes = [261.63, 329.63, 392.00, 523.25]; // C4, E4, G4, C5 arpeggio
    const t = this.ctx.currentTime;

    notes.forEach((freq, index) => {
      const noteTime = t + index * 0.08;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, noteTime);

      gain.gain.setValueAtTime(this.volume * 0.25, noteTime);
      gain.gain.exponentialRampToValueAtTime(0.01, noteTime + 0.3);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(noteTime);
      osc.stop(noteTime + 0.3);
    });
  }

  // Retro gaming sound for failure / Game Over
  playGameOver() {
    this.initCtx();
    if (!this.ctx) return;

    const notes = [400, 300, 200, 150];
    const t = this.ctx.currentTime;

    notes.forEach((freq, index) => {
      const noteTime = t + index * 0.12;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, noteTime);

      gain.gain.setValueAtTime(this.volume * 0.2, noteTime);
      gain.gain.exponentialRampToValueAtTime(0.01, noteTime + 0.2);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(noteTime);
      osc.stop(noteTime + 0.2);
    });
  }

  // Synthesizes a real live cyber-chiptune 8-bit background track looping
  startBgm() {
    this.initCtx();
    if (!this.ctx) return;
    if (this.isBgmPlaying) return;

    this.isBgmPlaying = true;
    this.currentStep = 0;

    const stepDuration = 60 / this.bpm / 2; // Eighth notes

    // Simple bassline and synth chords notes
    // I - V - VI - IV progression: Am - Em - F - C
    const bassline = [
      110.00, 110.00, 110.00, 110.00, // A2
      82.41, 82.41, 82.41, 82.41,     // E2
      87.31, 87.31, 87.31, 87.31,     // F2
      130.81, 130.81, 130.81, 130.81, // C3
    ];

    const melody = [
      440.00, 493.88, 523.25, 587.33,
      329.63, 0, 392.00, 440.00,
      349.23, 0, 440.00, 523.25,
      261.63, 329.63, 392.00, 523.25
    ];

    this.bgmGain = this.ctx.createGain();
    this.bgmGain.gain.setValueAtTime(this.volume * 0.15, this.ctx.currentTime);
    this.bgmGain.connect(this.ctx.destination);

    const playStep = () => {
      if (!this.isBgmPlaying || !this.ctx) return;

      const t = this.ctx.currentTime;
      const step = this.currentStep % 16;

      // 1. Play Bass note (on beats 0, 2, 4, etc)
      if (step % 2 === 0) {
        const oscBass = this.ctx.createOscillator();
        const bassGain = this.ctx.createGain();

        oscBass.type = 'triangle';
        oscBass.frequency.setValueAtTime(bassline[step], t);

        bassGain.gain.setValueAtTime(this.volume * 0.15, t);
        bassGain.gain.exponentialRampToValueAtTime(0.001, t + stepDuration * 1.8);

        oscBass.connect(bassGain);
        bassGain.connect(this.bgmGain!);

        oscBass.start(t);
        oscBass.stop(t + stepDuration * 1.8);
      }

      // 2. Play subtle Arpeggiated Melody note occasionally
      if (melody[step] > 0 && Math.random() > 0.3) {
        const oscMel = this.ctx.createOscillator();
        const melGain = this.ctx.createGain();

        oscMel.type = 'sine';
        oscMel.frequency.setValueAtTime(melody[step], t);

        melGain.gain.setValueAtTime(this.volume * 0.08, t);
        melGain.gain.exponentialRampToValueAtTime(0.001, t + stepDuration * 0.9);

        oscMel.connect(melGain);
        melGain.connect(this.bgmGain!);

        oscMel.start(t);
        oscMel.stop(t + stepDuration * 0.9);
      }

      // 3. Play simple highhat (synthesized white noise click on every 4 steps)
      if (step % 4 === 2) {
        const bufferSize = this.ctx.sampleRate * 0.03;
        const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          data[i] = Math.random() * 2 - 1;
        }

        const hat = this.ctx.createBufferSource();
        hat.buffer = buffer;

        const hatFilter = this.ctx.createBiquadFilter();
        hatFilter.type = 'highpass';
        hatFilter.frequency.setValueAtTime(7000, t);

        const hatGain = this.ctx.createGain();
        hatGain.gain.setValueAtTime(this.volume * 0.04, t);
        hatGain.gain.exponentialRampToValueAtTime(0.001, t + 0.03);

        hat.connect(hatFilter);
        hatFilter.connect(hatGain);
        hatGain.connect(this.bgmGain!);

        hat.start(t);
        hat.stop(t + 0.03);
      }

      this.currentStep++;
      const nextTime = (stepDuration * 1000) - 10; // Slightly shorter to avoid build up lag
      this.bgmInterval = setTimeout(playStep, nextTime);
    };

    playStep();
  }

  stopBgm() {
    this.isBgmPlaying = false;
    if (this.bgmInterval) {
      clearTimeout(this.bgmInterval);
      this.bgmInterval = null;
    }
    if (this.bgmGain) {
      this.bgmGain.disconnect();
      this.bgmGain = null;
    }
  }

  isBgmActive(): boolean {
    return this.isBgmPlaying;
  }
}

// Global Singleton
export const soundEngine = new SoundEngine();
