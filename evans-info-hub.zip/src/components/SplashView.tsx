import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Terminal, Shield, Sparkles, Volume2 } from 'lucide-react';
import { soundEngine } from './SoundEngine';

interface SplashViewProps {
  onOpen: () => void;
}

export default function SplashView({ onOpen }: SplashViewProps) {
  const [isActivating, setIsActivating] = useState(false);

  const handleEnter = () => {
    setIsActivating(true);
    // Play sweet synthesized laser effect
    soundEngine.playLaser();
    // Tiny delay for dramatic transition effect
    setTimeout(() => {
      onOpen();
    }, 850);
  };

  return (
    <div 
      id="splash-container" 
      className="relative flex flex-col items-center justify-center min-h-screen w-full bg-[#0d0a16] text-white overflow-hidden scanline select-none"
    >
      {/* Moving stars background */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(139,92,246,0.15)_0%,_transparent_65%)]" />
      
      {/* Decorative cyber grid lines */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <div className="w-full h-full bg-[linear-gradient(to_right,#8b5cf6_1px,transparent_1px),linear-gradient(to_bottom,#8b5cf6_1px,transparent_1px)] bg-[size:4rem_4rem]" />
      </div>

      {/* Floating neon tech indicators */}
      <div className="absolute top-4 left-4 flex items-center space-x-2 font-mono text-xs text-purple-400 tracking-widest uppercase animate-pulse">
        <Terminal size={14} className="text-purple-400" />
        <span>SYS_STATUS: READY</span>
      </div>

      <div className="absolute top-4 right-4 flex items-center space-x-2 font-mono text-xs text-red-500 tracking-widest uppercase">
        <Shield size={14} className="text-red-500" />
        <span>SECURE_SESSION_V4.9</span>
      </div>

      <div className="absolute bottom-6 font-mono text-xs text-gray-500 tracking-widest text-center px-4 max-w-xs md:max-w-md">
        <span>© 2026 EVAN'S LAB // DESHI TECH WORLD // CLICK OPEN TO BEGIN</span>
      </div>

      {/* Main glowing container */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.8, filter: 'blur(10px)' }}
        transition={{ type: 'spring', damping: 15 }}
        className="relative z-10 flex flex-col items-center max-w-lg px-6 text-center"
      >
        {/* Holographic Glowing Ring */}
        <div className="relative w-40 h-40 md:w-48 md:h-48 mb-8 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border border-purple-500/20 animate-ping" />
          <div className="absolute inset-2 rounded-full border-2 border-dashed border-cyan-400/40 animate-spin-slow" />
          <div className="absolute inset-4 rounded-full bg-gradient-to-tr from-purple-900/30 to-black border border-purple-500/40 shadow-[0_0_25px_rgba(168,85,247,0.4)]" />
          
          {/* Central Pulsing Crown / Emoji Emblem */}
          <div className="relative z-10 text-5xl md:text-6xl animate-bounce">
            👑
          </div>
        </div>

        {/* Title */}
        <motion.h1 
          className="text-4xl md:text-6xl font-extrabold font-sans tracking-tighter mb-2"
          initial={{ y: 20 }}
          animate={{ y: 0 }}
        >
          <span className="bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-400 bg-clip-text text-transparent drop-shadow-sm">
            EVAN'S INFO
          </span>
          <br />
          <span className="text-white glow-cyan tracking-wider font-mono text-3xl md:text-5xl font-bold">
            ⚡ HUB ⚡
          </span>
        </motion.h1>

        <p className="text-gray-400 text-sm md:text-base font-mono mb-8 max-w-sm mx-auto leading-relaxed">
          🍒 Welcome To My Bio Profile 🍒
          <span className="block mt-1 text-xs text-purple-400/80 italic font-sans">
            "Class: Out Of Your Mind 👹"
          </span>
        </p>

        {/* Enter Button */}
        <motion.button
          id="btn-open-hub"
          onClick={handleEnter}
          disabled={isActivating}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className={`relative group px-10 py-5 bg-gradient-to-r from-purple-600 via-pink-600 to-cyan-500 rounded-2xl font-bold tracking-widest text-lg uppercase transition-all duration-300 shadow-[0_0_30px_rgba(168,85,247,0.5)] border border-purple-300/30 overflow-hidden ${
            isActivating ? 'opacity-90 saturate-50' : ''
          }`}
        >
          {/* Button Background light glow */}
          <div className="absolute inset-0 w-full h-full bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
          
          <div className="relative z-10 flex items-center justify-center space-x-3 text-white">
            <Volume2 className="w-5 h-5 animate-pulse text-cyan-200" />
            <span className="font-mono tracking-wider">
              {isActivating ? 'LOADING...' : 'OPEN / প্রবেশ করুন'}
            </span>
            <Sparkles className="w-5 h-5 animate-spin text-pink-200" />
          </div>

          {/* Glowing bottom border animation */}
          <div className="absolute bottom-0 left-0 h-1 bg-cyan-400 animate-[pulse_1s_infinite] w-full" />
        </motion.button>

        {/* Audio Advice Hint */}
        <div className="mt-4 flex items-center justify-center space-x-1.5 text-[11px] font-mono text-purple-400/60">
          <span>🔊 Turn on Sound for Arcade Synths</span>
        </div>
      </motion.div>

      {/* Futuristic Grid Corners */}
      <div className="absolute top-8 left-8 w-6 h-6 border-t-2 border-l-2 border-purple-500 opacity-45" />
      <div className="absolute top-8 right-8 w-6 h-6 border-t-2 border-r-2 border-purple-500 opacity-45" />
      <div className="absolute bottom-8 left-8 w-6 h-6 border-b-2 border-l-2 border-purple-500 opacity-45" />
      <div className="absolute bottom-8 right-8 w-6 h-6 border-b-2 border-r-2 border-purple-500 opacity-45" />
    </div>
  );
}
