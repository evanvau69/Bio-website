import React from 'react';
import { Reaction } from '../types';

interface ReactionFloaterProps {
  reactions: Reaction[];
}

export default function ReactionFloater({ reactions }: ReactionFloaterProps) {
  return (
    <div 
      id="reaction-floater-overlay" 
      className="absolute inset-0 pointer-events-none z-50 overflow-hidden"
    >
      {reactions.map((r) => (
        <span
          key={r.id}
          className="reaction-particle text-3xl select-none"
          style={{
            left: `${r.x}%`,
            bottom: `${r.y}%`,
            transform: `rotate(${r.rotation}deg)`,
          }}
        >
          {r.emoji}
        </span>
      ))}
    </div>
  );
}
