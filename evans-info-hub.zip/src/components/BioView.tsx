import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, ShieldAlert, Heart, Calendar, Target, HelpCircle, 
  Send, ExternalLink, Globe, Volume2, VolumeX, Sparkles, Flame, Terminal, Shield
} from 'lucide-react';
import { soundEngine } from './SoundEngine';
import { Reaction, Language } from '../types';
import ReactionFloater from './ReactionFloater';
import RetroGames from './RetroGames';

export default function BioView() {
  const [lang, setLang] = useState<Language>('bn');
  const [reactions, setReactions] = useState<Reaction[]>([]);
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);
  const [musicVol, setMusicVol] = useState(0.4);
  const [totalReactions, setTotalReactions] = useState(() => {
    return parseInt(localStorage.getItem('evan_reactions_count') || '142', 10);
  });

  // Start Background music automatically upon reveal
  useEffect(() => {
    soundEngine.startBgm();
    setIsMusicPlaying(true);
    return () => {
      soundEngine.stopBgm();
    };
  }, []);

  const toggleMusic = () => {
    if (isMusicPlaying) {
      soundEngine.stopBgm();
      setIsMusicPlaying(false);
    } else {
      soundEngine.startBgm();
      setIsMusicPlaying(true);
    }
    soundEngine.playPop();
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vol = parseFloat(e.target.value);
    setMusicVol(vol);
    soundEngine.setVolume(vol);
  };

  // Flying reactions builder
  const triggerReaction = (emoji: string) => {
    soundEngine.playPop();
    setTotalReactions(prev => {
      const nextR = prev + 1;
      localStorage.setItem('evan_reactions_count', nextR.toString());
      return nextR;
    });

    const newReaction: Reaction = {
      id: Math.random().toString(),
      emoji,
      x: Math.random() * 80 + 10,
      y: 10,
      rotation: Math.random() * 60 - 30,
    };

    setReactions((prev) => [...prev, newReaction]);

    setTimeout(() => {
      setReactions((prev) => prev.filter((r) => r.id !== newReaction.id));
    }, 1200);
  };

  const t = {
    en: {
      bioTitle: "EVAN PROFILER",
      subTitle: "Welcome To My Bio Profile",
      religion: "Religion",
      religionVal: "Muslim 💯",
      from: "Origin",
      fromVal: "Bangladesh 🇧🇩",
      hobbies: "Hobbies",
      hobbiesVal: "Destroying The Enemy 💀",
      class: "Class",
      classVal: "Out Of Your Mind 👹",
      birthday: "Earth Arrival",
      birthdayVal: "August 12th ★★★★",
      goal: "Mission / Goal",
      goalVal: "Secret 😂 (Even Don't Have) 🍒",
      status: "Relationship",
      statusVal: "Pure Single 😐",
      working: "Working Project",
      workingVal: "🍑 WORKING FOR DESHI VABHI 🍑",
      disclaimer: "Disclaimer",
      disclaimerText: "Click below to boost Evan's Info Hub directly on Telegram. Feel free to use, test, and enjoy the games!",
      tgSettingsBtn: "Telegram Settings ⚙️",
      boostBtn: "Boost Info Hub 🚀",
      contactTitle: "CONNECTED TERMINALS",
      reactionTitle: "GIVE REACTIONS",
      reactionsLabel: "Total Reactions",
      copied: "Copied!",
      musicOn: "Music ON",
      musicOff: "Music MUTED",
    },
    bn: {
      bioTitle: "ইভান প্রোফাইলার",
      subTitle: "আমার বায়ো প্রোফাইলে স্বাগতম",
      religion: "ধর্ম",
      religionVal: "মুসলিম 💯",
      from: "দেশ",
      fromVal: "বাংলাদেশ 🇧🇩",
      hobbies: "আমার শখ",
      hobbiesVal: "শত্রু খতম করা 💀",
      class: "শ্রেণী",
      classVal: "তোমার কল্পনার বাইরে 👹",
      birthday: "জন্মদিন",
      birthdayVal: "১২ই আগস্ট ★★★★",
      goal: "লক্ষ্য",
      goalVal: "গোপন 😂 (আসলে লক্ষ্যই নেই) 🍒",
      status: "সম্পর্ক",
      statusVal: "একদম সিঙ্গেল 😐",
      working: "বর্তমান কাজ",
      workingVal: "🍑 WORKING FOR DESHI VABHI 🍑",
      disclaimer: "সতর্কবার্তা",
      disclaimerText: "টেলিগ্রামে ইভানের ইনফো হাব সরাসরি বুস্ট করতে নিচে ক্লিক করুন। গেম খেলতে এবং মিউজিক উপভোগ করতে প্রোফাইলটি ব্যবহার করুন!",
      tgSettingsBtn: "টেলিগ্রাম সেটিংস ⚙️",
      boostBtn: "ইনফো হাব বুস্ট করুন 🚀",
      contactTitle: "টেলিগ্রাম সিকিউর টার্মিনাল",
      reactionTitle: "রিয়্যাকশন দিন",
      reactionsLabel: "মোট রিয়্যাকশন সংখ্যা",
      copied: "কপি হয়েছে!",
      musicOn: "মিউজিক চালু",
      musicOff: "মিউজিক বন্ধ",
    },
  };

  const curr = lang === 'en' ? t.en : t.bn;

  return (
    <div 
      id="bio-main-view" 
      className="relative min-h-screen w-full bg-[#0A0A0B] text-white py-6 px-4 md:px-8 overflow-x-hidden scanline select-none font-sans"
    >
      {/* Absolute floating reaction overlay */}
      <ReactionFloater reactions={reactions} />

      {/* Modern Top Header Bar */}
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row gap-4 items-center justify-between mb-6 bg-[#161618] border border-[#2A2A2E] rounded-2xl p-4 relative z-20">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center text-2xl font-bold shadow-[0_0_15px_rgba(220,38,38,0.5)]">
            E
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">
              EVAN <span className="text-red-500 font-mono">PROFILER</span>
            </h1>
            <p className="text-xs text-gray-500 font-mono">ID: @Mr_evan3490 // Mr_evan3490</p>
          </div>
        </div>

        {/* Floating audio controls & translate option inside header */}
        <div className="flex flex-wrap items-center gap-3">
          
          {/* Audio Slider Control */}
          <div className="flex items-center space-x-2 bg-white/5 px-3.5 py-1.5 rounded-full border border-white/10 backdrop-blur-md">
            <button
              id="btn-toggle-bgm"
              onClick={toggleMusic}
              className="p-1 hover:bg-white/10 rounded-full text-red-500 transition-colors"
              title="Toggle Chiptune Music"
            >
              {isMusicPlaying ? <Volume2 size={16} className="animate-bounce" /> : <VolumeX size={16} />}
            </button>
            <input 
              type="range" 
              min="0" 
              max="1" 
              step="0.05"
              value={musicVol}
              onChange={handleVolumeChange}
              className="w-14 h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-red-500"
            />
            <span className="text-[10px] font-mono text-gray-400">
              {Math.round(musicVol * 100)}%
            </span>
          </div>

          {/* Language Toggle */}
          <button
            id="btn-lang-switch"
            onClick={() => {
              soundEngine.playPop();
              setLang(prev => prev === 'en' ? 'bn' : 'en');
            }}
            className="flex items-center space-x-1 px-3 py-1.5 bg-white/5 border border-white/10 rounded-full text-xs font-mono text-gray-400 hover:text-white transition-colors"
          >
            <Globe size={13} className="text-red-500" />
            <span>{lang === 'en' ? 'বাংলা' : 'English'}</span>
          </button>

          {/* Static badges */}
          <div className="hidden sm:flex gap-2">
            <div className="px-3 py-1 bg-red-500/10 border border-red-500/20 text-red-500 text-[10px] rounded-full uppercase tracking-widest font-bold">
              System Active
            </div>
            <div className="px-3 py-1 bg-white/5 border border-white/10 text-gray-400 text-[10px] rounded-full font-mono">
              v2.0.48
            </div>
          </div>
        </div>
      </div>

      {/* Main Bento Grid */}
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-4 relative z-10">
        
        {/* Identity Card (Large Block - Col Span 2, Row Span 2 on large) */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:col-span-2 md:row-span-2 bg-[#161618] border border-[#2A2A2E] rounded-3xl p-6 flex flex-col justify-between relative overflow-hidden group min-h-[440px]"
        >
          <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none select-none">
            <span className="text-9xl font-bold font-mono">01</span>
          </div>

          <div>
            <div className="text-red-500 font-mono text-xs mb-2 tracking-widest uppercase">// SUBJECT_PROFILE</div>
            <h2 className="text-4xl md:text-5xl font-black mb-4 tracking-tighter text-white">
              EVAN 🌟
            </h2>
            <div className="inline-block px-4 py-2 bg-white text-black font-bold text-xs rounded-lg mb-6 italic shadow-md">
              "Class: Out Of Your Mind 👹"
            </div>

            {/* Standard key info matching the aesthetic layout */}
            <div className="space-y-4 font-mono text-sm">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded bg-white/5 flex items-center justify-center text-lg">🇧🇩</div>
                <span className="text-gray-400">{curr.from}: <span className="text-white font-semibold">{curr.fromVal}</span></span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded bg-white/5 flex items-center justify-center text-lg">💯</div>
                <span className="text-gray-400">{curr.religion}: <span className="text-white font-semibold">{curr.religionVal}</span></span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded bg-white/5 flex items-center justify-center text-lg">📅</div>
                <span className="text-gray-400">{curr.birthday}: <span className="text-white font-semibold">{curr.birthdayVal}</span></span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded bg-white/5 flex items-center justify-center text-lg">😈</div>
                <span className="text-gray-400">{curr.class}: <span className="text-red-400 font-semibold">{curr.classVal}</span></span>
              </div>
            </div>
          </div>

          {/* Card footer */}
          <div className="mt-8 border-t border-white/5 pt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <span className="text-[10px] text-gray-500 uppercase tracking-widest font-mono">
              {curr.workingVal}
            </span>
            <span className="text-xs font-mono text-red-500 font-bold bg-red-500/10 px-2.5 py-1 rounded-md border border-red-500/20">
              [ STATUS: {curr.statusVal.toUpperCase()} ]
            </span>
          </div>
        </motion.div>

        {/* Hobbies Section (Crimson red color bento card) */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="col-span-1 bg-red-600 rounded-3xl p-6 flex flex-col justify-center items-center text-center shadow-[0_20px_50px_rgba(220,38,38,0.25)] relative overflow-hidden group cursor-pointer"
          whileHover={{ scale: 1.02 }}
          onClick={() => triggerReaction('💀')}
        >
          <div className="absolute top-2 right-3 text-[10px] font-mono text-white/40 tracking-widest uppercase">// 02</div>
          <div className="text-5xl mb-3 animate-float-slow select-none">💀</div>
          <h3 className="font-black text-xl uppercase tracking-tighter text-white">{curr.hobbies}</h3>
          <p className="text-sm font-bold opacity-90 mt-1">{curr.hobbiesVal}</p>
        </motion.div>

        {/* Secret Goal Section (Alternate dark block) */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="col-span-1 bg-[#1c1c21] border border-[#2A2A2E] rounded-3xl p-6 flex flex-col justify-center items-center text-center relative overflow-hidden"
        >
          <div className="absolute top-2 right-3 text-[10px] font-mono text-gray-600 tracking-widest uppercase">// 03</div>
          <div className="text-5xl mb-3 select-none">🍒</div>
          <h3 className="font-black text-xl uppercase tracking-tighter text-gray-400">{curr.goal}</h3>
          <p className="text-xs font-mono mt-2 text-red-500 underline decoration-dotted font-bold bg-red-500/10 px-2.5 py-1 rounded">
            {curr.goalVal}
          </p>
        </motion.div>

        {/* Interactive Reaction launcher Card (1 col, 1 row span) */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="col-span-1 bg-[#161618] border border-[#2A2A2E] rounded-3xl p-5 flex flex-col justify-between relative overflow-hidden"
        >
          <div className="absolute top-2 right-3 text-[10px] font-mono text-gray-600 tracking-widest uppercase">// 04</div>
          
          <div>
            <h3 className="text-sm font-black uppercase tracking-wider text-red-500 mb-1 flex items-center gap-1.5">
              <span>🔥</span> {curr.reactionTitle}
            </h3>
            <p className="text-[10px] font-mono text-gray-500 mb-4">
              Tap below to trigger visual particle sparks
            </p>

            {/* Quick launch reaction buttons */}
            <div className="grid grid-cols-5 gap-1.5 mb-4">
              {[
                { emoji: '🔥', label: 'FIRE' },
                { emoji: '❤️', label: 'LOVE' },
                { emoji: '💀', label: 'DEAD' },
                { emoji: '🍑', label: 'VABHI' },
                { emoji: '🌟', label: 'STAR' }
              ].map((btn) => (
                <button
                  key={btn.emoji}
                  id={`btn-react-${btn.label.toLowerCase()}`}
                  onClick={() => triggerReaction(btn.emoji)}
                  className="py-2.5 bg-white/5 hover:bg-red-500 hover:text-white transition-all rounded-lg text-lg flex items-center justify-center border border-white/5 hover:border-red-500 active:scale-95"
                >
                  <span className="select-none">{btn.emoji}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Stats given */}
          <div className="bg-black/30 p-2.5 rounded-xl border border-white/5 font-mono text-[10px] flex justify-between items-center">
            <span className="text-gray-500">{curr.reactionsLabel}:</span>
            <span className="text-red-500 font-bold text-xs bg-red-500/10 px-2 py-0.5 rounded border border-red-500/20">
              {totalReactions}
            </span>
          </div>
        </motion.div>

        {/* Support Bot / Help Center Card (High contrast white card, black text) */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="col-span-1 bg-white rounded-3xl p-5 flex flex-col justify-between text-black relative overflow-hidden group cursor-pointer hover:scale-[1.01] transition-transform"
          onClick={() => {
            soundEngine.playLaser();
            window.open('https://t.me/EVANHELPING_BOT', '_blank');
          }}
        >
          <div className="absolute top-2 right-3 text-[10px] font-mono text-black/30 tracking-widest uppercase">// 05</div>
          <div>
            <div className="text-[10px] font-mono font-bold uppercase mb-1 text-red-600 tracking-wider">SUPPORT BOT</div>
            <h3 className="font-black text-xl leading-none tracking-tight">
              EVAN HELPING<br />CENTRE
            </h3>
          </div>
          <div className="bg-black text-white p-2.5 rounded-xl text-center text-xs font-mono font-bold tracking-tight mt-6 group-hover:bg-red-600 transition-colors">
            @EVANHELPING_BOT
          </div>
        </motion.div>

        {/* Communication Hub / Connected Terminals List (Spans 2 cols on large) */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:col-span-2 bg-[#161618] border border-[#2A2A2E] rounded-3xl p-5 flex flex-col justify-between relative overflow-hidden"
        >
          <div className="absolute top-2 right-3 text-[10px] font-mono text-gray-600 tracking-widest uppercase">// 06</div>
          <div className="flex items-center gap-2 mb-4">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
            <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest font-mono">
              {curr.contactTitle}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Mr Evan */}
            <a 
              href="https://t.me/Mr_evan3490"
              target="_blank"
              rel="noreferrer"
              onClick={() => soundEngine.playLaser()}
              className="p-3 bg-white/5 rounded-xl border border-white/5 hover:border-red-500 transition-all flex justify-between items-center group font-mono text-xs"
            >
              <div>
                <span className="text-[9px] text-gray-500 block mb-0.5">Primary Client</span>
                <span className="text-white font-bold group-hover:text-red-400 transition-colors">@Mr_evan3490</span>
              </div>
              <ExternalLink size={12} className="text-gray-600 group-hover:text-red-400" />
            </a>

            {/* Owner accounts */}
            <a 
              href="https://t.me/Evans_methood"
              target="_blank"
              rel="noreferrer"
              onClick={() => soundEngine.playLaser()}
              className="p-3 bg-white/5 rounded-xl border border-white/5 hover:border-red-500 transition-all flex justify-between items-center group font-mono text-xs"
            >
              <div>
                <span className="text-[9px] text-gray-500 block mb-0.5">Owner Channel</span>
                <span className="text-white font-bold group-hover:text-red-400 transition-colors">@Evans_methood</span>
              </div>
              <ExternalLink size={12} className="text-gray-600 group-hover:text-red-400" />
            </a>
          </div>
        </motion.div>

        {/* Disclaimer / Boost card (1 col, 1 row span) */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="col-span-1 bg-[#161618] border border-dashed border-[#2A2A2E] rounded-3xl p-5 flex flex-col justify-center items-center text-center relative overflow-hidden"
        >
          <div className="text-[10px] text-gray-500 uppercase tracking-tighter font-mono mb-2">
            🚀 {curr.disclaimer.toUpperCase()}
          </div>
          <div className="flex gap-2 mb-3">
            <div className="w-7 h-7 rounded bg-red-600 flex items-center justify-center text-xs select-none">🔥</div>
            <div className="w-7 h-7 rounded bg-red-600 flex items-center justify-center text-xs select-none">🇯🇵</div>
            <div className="w-7 h-7 rounded bg-red-600 flex items-center justify-center text-xs select-none">🩷</div>
          </div>
          <a
            href="https://t.me/boost/Evans_Info_Hub"
            target="_blank"
            rel="noreferrer"
            onClick={() => soundEngine.playLaser()}
            className="text-[10px] font-mono text-red-500 hover:underline font-bold"
          >
            Evans_Info_Hub • {curr.boostBtn}
          </a>
        </motion.div>

        {/* Gaming Terminal Bento Section - Spans 4 entire columns for high fidelity and immersion */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:col-span-4 bg-[#161618] border border-[#2A2A2E] rounded-3xl p-6 relative overflow-hidden shadow-2xl"
        >
          <div className="absolute top-4 right-6 text-[10px] font-mono text-white/10 tracking-widest uppercase">// SYSTEM_ARCADE_ACTIVE</div>
          
          <div className="flex items-center gap-2.5 mb-4">
            <Terminal size={16} className="text-red-500" />
            <h3 className="text-lg font-black uppercase tracking-tighter italic text-red-500">
              RETRO TIMING TERMINAL & ENEMY ARCADE
            </h3>
          </div>

          <RetroGames />
        </motion.div>

      </div>

      {/* Modern Bottom Navigation / Logger Bar */}
      <div className="max-w-6xl mx-auto mt-8 flex flex-col md:flex-row items-center justify-between border-t border-[#2A2A2E] pt-4 gap-4 relative z-10">
        <div className="text-[10px] text-gray-500 uppercase font-mono font-bold tracking-widest flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse"></span>
          <span>SYSTEM LOG: USER @Mr_evan3490 ACTIVE SESSION</span>
        </div>
        <div className="flex flex-wrap gap-4 md:gap-6 font-mono">
          <a href="tg://settings" className="text-[10px] font-bold text-red-500 uppercase hover:underline">
            {curr.tgSettingsBtn}
          </a>
          <span className="text-[10px] font-bold text-gray-600 uppercase">
            EST. 2026
          </span>
          <span className="text-[10px] font-bold text-gray-600 uppercase">
            MADE WITH ❤️
          </span>
        </div>
      </div>
    </div>
  );
}

